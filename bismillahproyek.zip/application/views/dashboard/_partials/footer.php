<footer class="footer text-center">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Calon Asisten Laboratorium Matematika Unpad <?= date('Y'); ?></span>
        </div>

    </div>

    All Rights Reserved by Bayu. Designed and Developed by
</footer>
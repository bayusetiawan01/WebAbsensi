<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
<!-- Javascript untuk scroolbar -->
<script src="<?php echo base_url('assets/js/sparkline.js'); ?>"></script>
<!--Untuk efek gelombang -->
<script src="<?php echo base_url('assets/js/waves.js'); ?>"></script>
<!--Untuk menu -->
<script src="<?php echo base_url('assets/js/sidebarmenu.js'); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo base_url('assets/js/custom.js'); ?>"></script>
<!--Untuk grafik-->
<script src="<?php echo base_url('assets/js/chartist.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/chartist-plugin-tooltip.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/dashboard1.js'); ?>"></script>